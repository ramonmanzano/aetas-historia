/**
 * 
 */
/**
 * 
 */
module Proyecto {
	requires java.desktop;
	requires java.sql;
}