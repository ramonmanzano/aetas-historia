package Ventanas;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class LaVentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel PanelFondo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LaVentanaPrincipal frame = new LaVentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//////////////////////////////VENTANA PRINCIPAL/////////////////////////////////////////////////
	public LaVentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(336, 99, 636, 498);
		PanelFondo = new JPanel();
		PanelFondo.setForeground(new Color(0, 0, 0));
		PanelFondo.setBackground(new Color(244, 164, 96));
		PanelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(PanelFondo);
		PanelFondo.setLayout(null);
		
///////////////////////// BOTON INVESTIGADOR /////////////////////////////////////////
		JButton botonInvestigador = new JButton("Investigador");
		botonInvestigador.setBounds(239, 76, 137, 67);
		botonInvestigador.setBackground(new Color(244, 164, 96)); // Fondo tipo "Sandy Brown"
		botonInvestigador.setForeground(Color.WHITE);             // Texto blanco
		botonInvestigador.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente clara y legible
		botonInvestigador.setHorizontalAlignment(SwingConstants.CENTER); // Centrado horizontal
		botonInvestigador.setVerticalAlignment(SwingConstants.CENTER);
		botonInvestigador.setBorder(new RoundedBorder(25));
		PanelFondo.add(botonInvestigador);
		////////////////////////////////////////////////////////////////////////////////////
		
		
		/////////////////////////BOTON ADMINISTRADOR////////////////////////////////////////
		JButton botonAdministrador = new JButton("Administrador");
		botonAdministrador.setBounds(239, 165, 149, 67);
		botonAdministrador.setBackground(new Color(244, 164, 96)); // Fondo tipo "Sandy Brown"
		botonAdministrador.setForeground(Color.WHITE);             // Texto blanco
		botonAdministrador.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente clara y legible
		botonAdministrador.setHorizontalAlignment(SwingConstants.CENTER); // Centrado horizontal
		botonAdministrador.setVerticalAlignment(SwingConstants.CENTER);
		botonAdministrador.setBorder(new RoundedBorder(25)); // Borde redondeado suave
		
				// Acción al hacer clic
				botonAdministrador.addActionListener(new ActionListener() {
				    public void actionPerformed(ActionEvent e) {
				    	VentanaAccesoAdministrador x = new VentanaAccesoAdministrador();
				    	x.setVisible(true);
				    }
				});
				PanelFondo.add(botonAdministrador);
		/////////////////////////////////////////////////////////////////////////////////////
		
	
		/////////////////////////BOTON VISITANTE/////////////////////////////////////////////
		JButton botonVisitante = new JButton("Visitante");
		botonVisitante.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		botonVisitante.setBounds(220, 250, 201, 91);
		botonVisitante.setBackground(new Color(244, 164, 96)); // Fondo tipo "Sandy Brown"
		botonVisitante.setForeground(Color.WHITE);             // Texto blanco
		botonVisitante.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente clara y legible
		botonVisitante.setHorizontalAlignment(SwingConstants.CENTER); // Centrado horizontal
		botonVisitante.setVerticalAlignment(SwingConstants.CENTER);
		botonVisitante.setBorder(new RoundedBorder(25));
		PanelFondo.add(botonVisitante);
		///////////////////////////////////////7
		JButton botonVisitaVirtual = new JButton("Visita Virtual");
		botonVisitaVirtual.setVerticalAlignment(SwingConstants.CENTER);
		botonVisitaVirtual.setHorizontalAlignment(SwingConstants.CENTER);
		botonVisitaVirtual.setForeground(Color.WHITE);
		botonVisitaVirtual.setFont(new Font("Arial", Font.BOLD, 14));
		botonVisitaVirtual.setBorder(new RoundedBorder(25));
		botonVisitaVirtual.setBackground(new Color(244, 164, 96));
		botonVisitaVirtual.setBounds(220, 351, 201, 91);
		PanelFondo.add(botonVisitaVirtual);
		//////////////////////////////////////////////////////////////////////////////////////
	}
}
